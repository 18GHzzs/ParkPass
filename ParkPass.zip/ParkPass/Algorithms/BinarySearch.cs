using ParkPass.DataStructures;

namespace ParkPass.Algorithms;

/// <summary>
/// BINARY SEARCH - finds something in a SORTED list super fast (O(log n)).
///
/// It's like guessing a number from 1 to 100:
/// "Is it 50?" -> "Higher!" -> now only 51-100 are left. Every guess throws away HALF the choices.
/// IMPORTANT: the list must already be sorted, or it won't work.
/// </summary>
public static class BinarySearch
{
    /// <param name="sorted">A list sorted by the same key we are looking for (sorted with ordinal order).</param>
    /// <param name="key">The text we are looking for, like a plate number.</param>
    /// <param name="keyOf">Tells us which text of each item to look at.</param>
    /// <returns>The spot number of the item, or -1 if it is not in the list.</returns>
    public static int Find<T>(SimpleList<T> sorted, string key, Func<T, string> keyOf)
    {
        int low = 0;
        int high = sorted.Count - 1;

        while (low <= high)
        {
            int middle = low + (high - low) / 2;
            int answer = string.CompareOrdinal(keyOf(sorted[middle]), key);

            if (answer == 0) return middle;          // found it!
            if (answer < 0) low = middle + 1;        // too small -> look in the upper half
            else high = middle - 1;                  // too big   -> look in the lower half
        }
        return -1;                                   // not found
    }
}
