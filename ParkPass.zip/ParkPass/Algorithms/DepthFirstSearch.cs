using ParkPass.DataStructures;

namespace ParkPass.Algorithms;

/// <summary>The answer of a route search: where to drive and how far it is.</summary>
public class RouteResult
{
    public bool Found { get; }
    public SimpleList<string> Path { get; }
    public int TotalDistance { get; }

    public RouteResult(bool found, SimpleList<string> path, int totalDistance)
    {
        Found = found;
        Path = path;
        TotalDistance = totalDistance;
    }

    /// <summary>The last stop on the path (the parking lot we want).</summary>
    public string Destination => Path.Count > 0 ? Path[Path.Count - 1] : "";

    public static RouteResult NotFound() => new(false, new SimpleList<string>(), 0);
}

/// <summary>
/// DEPTH-FIRST SEARCH (DFS) - explores the map like walking through a maze:
/// go down one road as far as you can, and when you hit a dead end, go BACK and try another road.
///
/// We let DFS try every possible way from the gate to a parking lot that has space,
/// add up the road lengths each time, and remember the SHORTEST one.
/// </summary>
public static class DepthFirstSearch
{
    // A little notebook that remembers the best route found so far.
    private class BestRoute
    {
        public int Distance = int.MaxValue;
        public SimpleList<string>? Path;
    }

    /// <param name="graph">The campus map.</param>
    /// <param name="startName">Where the driver starts (the gate).</param>
    /// <param name="isGoal">A question: "Is THIS place a good place to stop?" (a lot with vacancy)</param>
    public static RouteResult FindShortestRoute(RoadGraph graph, string startName, Func<Vertex, bool> isGoal)
    {
        Vertex? start = graph.GetPlace(startName);
        if (start == null) return RouteResult.NotFound();

        var best = new BestRoute();
        var currentPath = new SimpleList<Vertex>();   // the places we walked through so far
        Explore(start, 0, currentPath, isGoal, best);

        return best.Path == null
            ? RouteResult.NotFound()
            : new RouteResult(true, best.Path, best.Distance);
    }

    private static void Explore(Vertex place, int distanceSoFar, SimpleList<Vertex> currentPath,
                                Func<Vertex, bool> isGoal, BestRoute best)
    {
        // Already longer than a route we found before? No point going on.
        if (distanceSoFar >= best.Distance) return;

        currentPath.Add(place);   // step onto this place

        if (isGoal(place))
        {
            // We reached a good parking lot! Save this route as the new best one.
            best.Distance = distanceSoFar;
            best.Path = new SimpleList<string>();
            foreach (Vertex v in currentPath) best.Path.Add(v.Name);
        }
        else
        {
            // Try every road that starts here.
            foreach (Edge road in place.Roads)
            {
                // Don't walk in circles: skip places already on our path.
                if (currentPath.Contains(road.To)) continue;
                Explore(road.To, distanceSoFar + road.Distance, currentPath, isGoal, best);
            }
        }

        currentPath.RemoveAt(currentPath.Count - 1);   // step BACK (backtrack) so other roads can be tried
    }
}
