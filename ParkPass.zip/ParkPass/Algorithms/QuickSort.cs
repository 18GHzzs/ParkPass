using ParkPass.DataStructures;

namespace ParkPass.Algorithms;

/// <summary>
/// QUICK SORT - puts things in order, fast (O(n log n) on average).
///
/// How it works (like sorting kids by height):
///  1. Pick one kid, the "pivot".
///  2. Kids shorter than the pivot go to the left, taller kids go to the right.
///  3. Now the pivot is in its final spot!
///  4. Do the same trick again for the left group and the right group.
/// </summary>
public static class QuickSort
{
    /// <param name="compare">
    /// A tiny rule that says which of two items comes first.
    /// Negative = first one goes first, 0 = same, positive = second one goes first.
    /// </param>
    public static void Sort<T>(SimpleList<T> list, Comparison<T> compare)
    {
        if (list.Count > 1)
            Sort(list, 0, list.Count - 1, compare);
    }

    private static void Sort<T>(SimpleList<T> list, int low, int high, Comparison<T> compare)
    {
        if (low >= high) return;                              // 0 or 1 item = already sorted
        int pivotSpot = Partition(list, low, high, compare);  // split into two groups
        Sort(list, low, pivotSpot - 1, compare);              // sort the left group
        Sort(list, pivotSpot + 1, high, compare);             // sort the right group
    }

    private static int Partition<T>(SimpleList<T> list, int low, int high, Comparison<T> compare)
    {
        // Choose the MIDDLE item as pivot and hide it at the end (this avoids slow cases on sorted data).
        int middle = low + (high - low) / 2;
        list.Swap(middle, high);
        T pivot = list[high];

        int boundary = low;   // everything before this spot is "smaller or equal"
        for (int i = low; i < high; i++)
        {
            if (compare(list[i], pivot) <= 0)
            {
                list.Swap(i, boundary);
                boundary++;
            }
        }
        list.Swap(boundary, high);   // put the pivot into its final spot
        return boundary;
    }
}
