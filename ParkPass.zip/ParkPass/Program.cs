using ParkPass.Models;
using ParkPass.Services;

namespace ParkPass;

/// <summary>The front door of the program. It only starts the app and shows the LOG IN screen.</summary>
public static class Program
{
    public static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        // The accounts file lives in the folder where the program runs. Open it with Notepad to edit it.
        var app = new ParkPassSystem("accounts.csv");
        Console.WriteLine("ParkPass - MMCL Parking System");
        Console.WriteLine($"Accounts file: {app.Accounts.FilePath}");

        while (true)
        {
            Account? account = LogIn(app);
            if (account == null) break;   // the person typed "exit"

            // The account's ROLE decides which menu opens. Both menus are a MenuBase (POLYMORPHISM).
            MenuBase menu = account.IsOperator
                ? new OperatorMenu(app, account)
                : new UserMenu(app, account);
            menu.Run();
        }

        Console.WriteLine("Goodbye! Drive safe.");
    }

    /// <summary>Asks for a username and password until they are right. Gives back null if the person types "exit".</summary>
    private static Account? LogIn(ParkPassSystem app)
    {
        Console.WriteLine("\n----- LOG IN  (type 'exit' as username to quit) -----");
        while (true)
        {
            Console.Write("Username: ");
            string username = Console.ReadLine()?.Trim() ?? "";
            if (username.Equals("exit", StringComparison.OrdinalIgnoreCase)) return null;

            Console.Write("Password: ");
            string password = Console.ReadLine() ?? "";

            Account? account = app.Accounts.Login(username, password);
            if (account != null)
            {
                Console.WriteLine($"Welcome, {account.Name}! (logged in as {(account.IsOperator ? "Operator" : "User")})");
                return account;
            }
            Console.WriteLine("Wrong username or password. Try again.");
        }
    }
}
