namespace ParkPass.Models;

/// <summary>
/// One line in the guard's logbook: who came in, where they parked, and when.
/// This replaces one line of the old paper notebook.
/// </summary>
public class LogRecord
{
    public Vehicle Vehicle { get; }
    public string LotName { get; }
    public string SlotName { get; }
    public DateTime TimeIn { get; }
    public DateTime? TimeOut { get; private set; }   // "?" means it can be empty (still parked)

    public LogRecord(Vehicle vehicle, string lotName, string slotName, DateTime timeIn)
    {
        Vehicle = vehicle;
        LotName = lotName;
        SlotName = slotName;
        TimeIn = timeIn;
    }

    /// <summary>True while the vehicle is still inside the campus.</summary>
    public bool IsInside => TimeOut == null;

    /// <summary>Writes down the time the vehicle left.</summary>
    public void CheckOut(DateTime time) => TimeOut = time;

    public TimeSpan Duration => (TimeOut ?? DateTime.Now) - TimeIn;
}
