namespace ParkPass.Models;

/// <summary>A teacher or staff driver. Works like Student, but has a department instead of a course.</summary>
public class Faculty : User
{
    public string Department { get; private set; }

    public Faculty(string employeeId, string name, string department) : base(employeeId, name)
    {
        Department = department.Trim().ToUpperInvariant();
    }

    public override string Role => "Faculty";
    public override string Group => Department;
    public override string RoleCode => "F";
}
