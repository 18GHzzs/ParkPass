using ParkPass.DataStructures;

namespace ParkPass.Models;

/// <summary>Which kind of day are we looking at? Thursday is lab day, other days are lecture days.</summary>
public enum DayProfile
{
    RegularLecture,
    ThursdayLab
}

/// <summary>The finished "traffic homework" the analytics service hands back.</summary>
public class TrafficReport
{
    public DayProfile Profile { get; init; }
    public int DaysObserved { get; init; }
    public double[] HourlyAverages { get; init; } = new double[24];
    public double DailyAverage { get; init; }
    public HourCount PeakHour { get; init; }
    public SimpleStack<HourCount> RushHourStack { get; init; } = new();
    public SimpleList<HourCount> BestArrivalHours { get; init; } = new();
}
