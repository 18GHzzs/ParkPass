namespace ParkPass.Models;

/// <summary>A student driver. Inherits (copies) everything from User and adds a course.</summary>
public class Student : User
{
    public string Course { get; private set; }

    public Student(string studentId, string name, string course) : base(studentId, name)
    {
        Course = course.Trim().ToUpperInvariant();
    }

    // "override" = this child gives its OWN answer (POLYMORPHISM).
    public override string Role => "Student";
    public override string Group => Course;
    public override string RoleCode => "S";
}
