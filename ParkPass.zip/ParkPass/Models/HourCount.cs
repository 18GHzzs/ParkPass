namespace ParkPass.Models;

/// <summary>"At this hour, this many vehicles arrive on average." Used by the traffic stack.</summary>
public readonly record struct HourCount(int Hour, double Average)
{
    /// <summary>Turns 13 into "1:00 PM" so people can read it easily.</summary>
    public static string HourLabel(int hour) => new DateTime(2000, 1, 1, hour, 0, 0).ToString("h:00 tt");
}
