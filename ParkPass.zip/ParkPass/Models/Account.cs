namespace ParkPass.Models;

/// <summary>
/// What is this account allowed to do?
///   Operator = the security guard (full control of the gate)
///   User     = a student or faculty driver (can only look at their own information)
/// </summary>
public enum AccountRole
{
    Operator,
    User
}

/// <summary>One login: a username, a password, a role, and (for drivers) their vehicle.</summary>
public class Account
{
    public string Username { get; }
    public string Password { get; }
    public AccountRole Role { get; }
    public string Name { get; }

    /// <summary>Only drivers have a vehicle. For a guard this stays empty (null).</summary>
    public Vehicle? Vehicle { get; }

    public Account(string username, string password, AccountRole role, string name, Vehicle? vehicle)
    {
        Username = username;
        Password = password;
        Role = role;
        Name = name;
        Vehicle = vehicle;
    }

    public bool IsOperator => Role == AccountRole.Operator;
}
