namespace ParkPass.Models;

/// <summary>
/// The two kinds of vehicles that can park on campus.
/// An "enum" is just a short list of allowed choices.
/// </summary>
public enum VehicleType
{
    Car,
    Motorcycle
}
