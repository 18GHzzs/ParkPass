namespace ParkPass.Models;

/// <summary>A vehicle with a plate number, a type, and an owner.</summary>
public class Vehicle
{
    public string Plate { get; private set; }
    public VehicleType Type { get; private set; }
    public User Owner { get; private set; }

    public Vehicle(string plate, VehicleType type, User owner)
    {
        Plate = NormalizePlate(plate);
        Type = type;
        Owner = owner;
    }

    /// <summary>
    /// Makes plates look the same every time: "abc 123" and "ABC-123" both become "ABC123".
    /// This way the computer never gets confused by spaces or small letters.
    /// </summary>
    public static string NormalizePlate(string plate)
    {
        return plate.Replace(" ", "").Replace("-", "").ToUpperInvariant();
    }

    public override string ToString() => $"{Plate} ({Type}) - {Owner.Name} [{Owner.Group}]";
}
