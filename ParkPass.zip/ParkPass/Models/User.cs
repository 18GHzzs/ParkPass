namespace ParkPass.Models;

/// <summary>
/// A person who owns a vehicle. This is a "parent" (abstract) class:
/// you can't make a plain User, you must make a Student or a Faculty.
/// OOP ideas used here: ABSTRACTION (hide details) and INHERITANCE (children copy the parent).
/// </summary>
public abstract class User
{
    // "private set" = only this class can change the value (ENCAPSULATION: keep data safe).
    public string Id { get; private set; }
    public string Name { get; private set; }

    protected User(string id, string name)
    {
        Id = id.Trim();
        Name = name.Trim();
    }

    /// <summary>Each child class says what kind of person it is (e.g. "Student").</summary>
    public abstract string Role { get; }

    /// <summary>Students have a course, faculty have a department. Both are shown as "group".</summary>
    public abstract string Group { get; }

    /// <summary>The one-letter code used inside the QR code text (S or F).</summary>
    public abstract string RoleCode { get; }
}
