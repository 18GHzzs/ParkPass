using System.Collections;

namespace ParkPass.DataStructures;

/// <summary>
/// Our own LIST, built from scratch as a LINKED LIST.
/// Think of a treasure hunt: every clue (node) holds a prize (the value) and tells you
/// where the NEXT clue is. We only remember where the first clue (head) and the last clue (tail) are.
/// The "T" means "any type": it can hold vehicles, numbers, words... anything.
/// </summary>
public class SimpleList<T> : IEnumerable<T>
{
    // One clue in the treasure hunt: holds a value and points to the next clue.
    private class Node
    {
        public T Value;
        public Node? Next;      // empty (null) when this is the last clue
        public Node(T value) { Value = value; }
    }

    private Node? _head;        // the first clue
    private Node? _tail;        // the last clue (so adding at the end is quick)
    public int Count { get; private set; }   // how many clues there are

    /// <summary>Lets us write list[2] to get or set the 3rd item. We must walk from the head to reach it.</summary>
    public T this[int index]
    {
        get { return GetNode(index).Value; }
        set { GetNode(index).Value = value; }
    }

    /// <summary>Put a new item at the end of the list.</summary>
    public void Add(T item)
    {
        var node = new Node(item);
        if (_tail == null) { _head = node; _tail = node; }   // empty list: the new node is first AND last
        else { _tail.Next = node; _tail = node; }            // old last node points to the new one
        Count++;
    }

    /// <summary>Take an item out by re-connecting the clues around it. Nothing needs to slide over.</summary>
    public void RemoveAt(int index)
    {
        CheckIndex(index);

        if (index == 0)
        {
            _head = _head!.Next;                  // the second clue becomes the first
            if (_head == null) _tail = null;      // the list became empty
        }
        else
        {
            Node before = GetNode(index - 1);     // the clue just before the one we remove
            Node removed = before.Next!;
            before.Next = removed.Next;           // skip over the removed clue
            if (removed == _tail) _tail = before; // we removed the last one, so the tail moves back
        }
        Count--;
    }

    public int IndexOf(T item)
    {
        var comparer = EqualityComparer<T>.Default;
        int spot = 0;
        for (Node? current = _head; current != null; current = current.Next)
        {
            if (comparer.Equals(current.Value, item)) return spot;
            spot++;
        }
        return -1;
    }

    public bool Contains(T item) => IndexOf(item) >= 0;

    /// <summary>Swap two items' values (the sorting algorithm uses this a lot).</summary>
    public void Swap(int a, int b)
    {
        Node first = GetNode(a);
        Node second = GetNode(b);
        (first.Value, second.Value) = (second.Value, first.Value);
    }

    /// <summary>Make a separate copy so sorting the copy does not mess up the original.</summary>
    public SimpleList<T> Copy()
    {
        var copy = new SimpleList<T>();
        for (Node? current = _head; current != null; current = current.Next)
            copy.Add(current.Value);
        return copy;
    }

    /// <summary>Walks from the first clue, following "Next" until we reach the wanted spot.</summary>
    private Node GetNode(int index)
    {
        CheckIndex(index);
        Node current = _head!;
        for (int i = 0; i < index; i++)
            current = current.Next!;
        return current;
    }

    private void CheckIndex(int index)
    {
        if (index < 0 || index >= Count)
            throw new IndexOutOfRangeException($"There is no spot number {index}. The list has {Count} items.");
    }

    // These two let us use "foreach" on our list.
    public IEnumerator<T> GetEnumerator()
    {
        Node? current = _head;
        while (current != null)
        {
            yield return current.Value;
            current = current.Next;
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
