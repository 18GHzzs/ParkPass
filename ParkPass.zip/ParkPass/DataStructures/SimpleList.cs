using System.Collections;

namespace ParkPass.DataStructures;

/// <summary>
/// Our own LIST, built from scratch.
/// Think of a row of boxes. When the row is full, we get a bigger row and move everything over.
/// The "T" means "any type": it can hold vehicles, numbers, words... anything.
/// </summary>
public class SimpleList<T> : IEnumerable<T>
{
    private T[] _items = new T[4];          // the row of boxes
    public int Count { get; private set; }  // how many boxes are really used

    /// <summary>Lets us write list[2] to get or set the 3rd item.</summary>
    public T this[int index]
    {
        get { CheckIndex(index); return _items[index]; }
        set { CheckIndex(index); _items[index] = value; }
    }

    /// <summary>Put a new item at the end of the list.</summary>
    public void Add(T item)
    {
        if (Count == _items.Length) MakeBigger();
        _items[Count] = item;
        Count++;
    }

    /// <summary>Take an item out and slide the others forward to fill the gap.</summary>
    public void RemoveAt(int index)
    {
        CheckIndex(index);
        for (int i = index; i < Count - 1; i++)
            _items[i] = _items[i + 1];
        Count--;
        _items[Count] = default!;
    }

    public int IndexOf(T item)
    {
        var comparer = EqualityComparer<T>.Default;
        for (int i = 0; i < Count; i++)
            if (comparer.Equals(_items[i], item)) return i;
        return -1;
    }

    public bool Contains(T item) => IndexOf(item) >= 0;

    /// <summary>Swap two items' places (the sorting algorithm uses this a lot).</summary>
    public void Swap(int a, int b)
    {
        CheckIndex(a);
        CheckIndex(b);
        (_items[a], _items[b]) = (_items[b], _items[a]);
    }

    /// <summary>Make a separate copy so sorting the copy does not mess up the original.</summary>
    public SimpleList<T> Copy()
    {
        var copy = new SimpleList<T>();
        for (int i = 0; i < Count; i++) copy.Add(_items[i]);
        return copy;
    }

    private void MakeBigger()
    {
        T[] bigger = new T[_items.Length * 2];
        for (int i = 0; i < Count; i++) bigger[i] = _items[i];
        _items = bigger;
    }

    private void CheckIndex(int index)
    {
        if (index < 0 || index >= Count)
            throw new IndexOutOfRangeException($"There is no box number {index}. The list has {Count} items.");
    }

    // These two let us use "foreach" on our list.
    public IEnumerator<T> GetEnumerator()
    {
        for (int i = 0; i < Count; i++) yield return _items[i];
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
