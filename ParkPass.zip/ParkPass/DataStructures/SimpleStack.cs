using System.Collections;

namespace ParkPass.DataStructures;

/// <summary>
/// Our own STACK (LIFO = Last In, First Out).
/// Imagine a pile of pancakes: you add on top, and you take from the top.
/// The last pancake you put on is the first one you eat.
/// </summary>
public class SimpleStack<T> : IEnumerable<T>
{
    private readonly SimpleList<T> _items = new();   // the pile is kept inside a list

    public int Count => _items.Count;
    public bool IsEmpty => _items.Count == 0;

    /// <summary>Put something on TOP of the pile.</summary>
    public void Push(T item) => _items.Add(item);

    /// <summary>Take the TOP thing off the pile and give it back.</summary>
    public T Pop()
    {
        if (IsEmpty) throw new InvalidOperationException("The stack is empty, nothing to pop.");
        T top = _items[_items.Count - 1];
        _items.RemoveAt(_items.Count - 1);
        return top;
    }

    /// <summary>Look at the TOP thing without taking it.</summary>
    public T Peek()
    {
        if (IsEmpty) throw new InvalidOperationException("The stack is empty.");
        return _items[_items.Count - 1];
    }

    /// <summary>Look at the very BOTTOM thing of the pile.</summary>
    public T PeekBottom()
    {
        if (IsEmpty) throw new InvalidOperationException("The stack is empty.");
        return _items[0];
    }

    /// <summary>Walk through the pile from the top down to the bottom.</summary>
    public IEnumerator<T> GetEnumerator()
    {
        for (int i = _items.Count - 1; i >= 0; i--) yield return _items[i];
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
