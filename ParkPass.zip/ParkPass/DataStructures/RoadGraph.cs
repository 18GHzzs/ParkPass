namespace ParkPass.DataStructures;

/// <summary>A road that leads to another place, and how many meters long it is (the "weight").</summary>
public class Edge
{
    public Vertex To { get; }
    public int Distance { get; }

    public Edge(Vertex to, int distance)
    {
        To = to;
        Distance = distance;
    }
}

/// <summary>A place on the campus map: a gate, a crossing, or a parking lot.</summary>
public class Vertex
{
    public string Name { get; }
    public bool IsParkingLot { get; }
    public SimpleList<Edge> Roads { get; } = new();   // all roads that start here

    public Vertex(string name, bool isParkingLot)
    {
        Name = name;
        IsParkingLot = isParkingLot;
    }
}

/// <summary>
/// The campus road MAP (a graph).
/// Dots (vertices) are places. Lines (edges) are roads. Each road has a length.
/// </summary>
public class RoadGraph
{
    private readonly SimpleList<Vertex> _vertices = new();

    public Vertex AddPlace(string name, bool isParkingLot = false)
    {
        var vertex = new Vertex(name, isParkingLot);
        _vertices.Add(vertex);
        return vertex;
    }

    /// <summary>Connect two places with a two-way road.</summary>
    public void AddRoad(string placeA, string placeB, int distance)
    {
        Vertex a = GetPlace(placeA) ?? throw new ArgumentException($"Unknown place '{placeA}'.");
        Vertex b = GetPlace(placeB) ?? throw new ArgumentException($"Unknown place '{placeB}'.");
        a.Roads.Add(new Edge(b, distance));
        b.Roads.Add(new Edge(a, distance));
    }

    public Vertex? GetPlace(string name)
    {
        foreach (Vertex v in _vertices)
            if (v.Name == name) return v;
        return null;
    }
}
