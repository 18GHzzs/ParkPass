using System.Collections;

namespace ParkPass.DataStructures;

/// <summary>
/// Our own QUEUE (FIFO = First In, First Out).
/// Just like a line at the canteen: whoever lines up first gets served first.
/// It is built from little "nodes" that point to the next one, like kids holding hands in a line.
/// </summary>
public class SimpleQueue<T> : IEnumerable<T>
{
    // One kid in the line: holds a value and points to the kid behind.
    private class Node
    {
        public T Value;
        public Node? Next;
        public Node(T value) { Value = value; }
    }

    private Node? _front;   // first kid in line
    private Node? _back;    // last kid in line
    public int Count { get; private set; }
    public bool IsEmpty => Count == 0;

    /// <summary>Join the END of the line.</summary>
    public void Enqueue(T item)
    {
        var node = new Node(item);
        if (_back == null) { _front = node; _back = node; }
        else { _back.Next = node; _back = node; }
        Count++;
    }

    /// <summary>The FRONT of the line leaves and is returned.</summary>
    public T Dequeue()
    {
        if (_front == null) throw new InvalidOperationException("The queue is empty.");
        T value = _front.Value;
        _front = _front.Next;
        if (_front == null) _back = null;
        Count--;
        return value;
    }

    /// <summary>See who is at the front without letting them leave.</summary>
    public T Peek()
    {
        if (_front == null) throw new InvalidOperationException("The queue is empty.");
        return _front.Value;
    }

    public IEnumerator<T> GetEnumerator()
    {
        Node? current = _front;
        while (current != null)
        {
            yield return current.Value;
            current = current.Next;
        }
    }
    IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
}
