using ParkPass.Models;

namespace ParkPass.DataStructures;

/// <summary>What floor of the "family tree" is this box on?</summary>
public enum NodeLevel
{
    Root,      // the whole campus
    Lot,       // Left Lot / Right Lot
    Section,   // Car or Motorcycle
    Slot       // one single parking space
}

/// <summary>
/// One box in the tree. A box can have children (boxes below it).
/// Example: "Left Lot" has two children: "Car" and "Motorcycle".
/// </summary>
public class ParkingNode
{
    public string Name { get; }
    public NodeLevel Level { get; }
    public ParkingNode? Parent { get; }
    public SimpleList<ParkingNode> Children { get; } = new();

    // These two only matter for Slot boxes.
    public bool IsOccupied { get; set; }
    public string? ParkedPlate { get; set; }

    public ParkingNode(string name, NodeLevel level, ParkingNode? parent)
    {
        Name = name;
        Level = level;
        Parent = parent;
    }

    public ParkingNode AddChild(string name, NodeLevel level)
    {
        var child = new ParkingNode(name, level, this);
        Children.Add(child);
        return child;
    }
}

/// <summary>
/// The parking TREE:
///   Campus Parking
///     |-- Left Lot
///     |     |-- Car          (slots L-C01, L-C02 ...)
///     |     |-- Motorcycle   (slots L-M01 ...)
///     |-- Right Lot
///           |-- ...
/// </summary>
public class ParkingTree
{
    public ParkingNode Root { get; } = new("Campus Parking", NodeLevel.Root, null);

    /// <summary>Add a new parking lot under the root.</summary>
    public void AddLot(string lotName) => Root.AddChild(lotName, NodeLevel.Lot);

    /// <summary>Add a Car or Motorcycle section to a lot and create its slots.</summary>
    public void AddSection(string lotName, VehicleType type, int slotCount)
    {
        ParkingNode lot = FindChild(Root, lotName)
            ?? throw new ArgumentException($"There is no lot named '{lotName}'.");

        ParkingNode section = lot.AddChild(type.ToString(), NodeLevel.Section);

        // Slot names look like "L-C01" (Left, Car, number 1).
        string prefix = $"{lotName[0]}-{type.ToString()[0]}";
        for (int i = 1; i <= slotCount; i++)
            section.AddChild($"{prefix}{i:00}", NodeLevel.Slot);
    }

    public SimpleList<ParkingNode> GetLots() => Root.Children;

    /// <summary>Count how many slots are empty in one section of one lot.</summary>
    public int CountFree(string lotName, VehicleType type)
    {
        ParkingNode? section = GetSection(lotName, type);
        if (section == null) return 0;
        int free = 0;
        foreach (ParkingNode slot in section.Children)
            if (!slot.IsOccupied) free++;
        return free;
    }

    public int CountTotal(string lotName, VehicleType type)
        => GetSection(lotName, type)?.Children.Count ?? 0;

    /// <summary>Find the first empty slot in that section and mark it as taken.</summary>
    public ParkingNode? TakeFreeSlot(string lotName, VehicleType type, string plate)
    {
        ParkingNode? section = GetSection(lotName, type);
        if (section == null) return null;
        foreach (ParkingNode slot in section.Children)
        {
            if (!slot.IsOccupied)
            {
                slot.IsOccupied = true;
                slot.ParkedPlate = plate;
                return slot;
            }
        }
        return null;   // no empty slot
    }

    /// <summary>Make a slot empty again, looking for it by name.</summary>
    public bool ReleaseSlot(string slotName)
    {
        ParkingNode? slot = FindSlotByName(Root, slotName);
        if (slot == null) return false;
        slot.IsOccupied = false;
        slot.ParkedPlate = null;
        return true;
    }

    private ParkingNode? GetSection(string lotName, VehicleType type)
    {
        ParkingNode? lot = FindChild(Root, lotName);
        return lot == null ? null : FindChild(lot, type.ToString());
    }

    private static ParkingNode? FindChild(ParkingNode parent, string name)
    {
        foreach (ParkingNode child in parent.Children)
            if (child.Name == name) return child;
        return null;
    }

    // Walks down every branch of the tree until it finds the slot. (Recursion = a method that calls itself.)
    private static ParkingNode? FindSlotByName(ParkingNode node, string slotName)
    {
        if (node.Level == NodeLevel.Slot && node.Name == slotName) return node;
        foreach (ParkingNode child in node.Children)
        {
            ParkingNode? found = FindSlotByName(child, slotName);
            if (found != null) return found;
        }
        return null;
    }
}
