using ParkPass.Models;
using ParkPass.Services.QrCode;

namespace ParkPass.Services;

/// <summary>The menu for the security GUARD (the Operator). The guard runs the gate.</summary>
public class OperatorMenu : MenuBase
{
    public OperatorMenu(ParkPassSystem app, Account me) : base(app, me) { }

    public override void Run()
    {
        bool running = true;
        while (running)
        {
            Console.WriteLine($"\n===== OPERATOR MENU - {Me.Name} =====");
            Console.WriteLine(" 1. Scan QR code (scanner / paste text / picture path) -> check in or out");
            Console.WriteLine(" 2. Scan QR code from a picture file         -> check in or out");
            Console.WriteLine(" 3. Register a new vehicle (scanner / paste text / picture path)");
            Console.WriteLine(" 4. Look up a vehicle (plate or ID)");
            Console.WriteLine(" 5. Show gate waiting queue");
            Console.WriteLine(" 6. Show parking availability");
            Console.WriteLine(" 7. Traffic analytics (rush hours, best arrival times)");
            Console.WriteLine(" 8. End-of-day report (sorted)");
            Console.WriteLine(" 9. Show sample QR texts (for testing)");
            Console.WriteLine(" 0. Log out");

            switch (Ask("Choose > "))
            {
                case "1": ScanAndProcess(AskForReader()); break;
                case "2": ScanAndProcess(new ImageQrReader(Ask("Path of the QR picture (png/jpg) > "))); break;
                case "3": RegisterFromQr(); break;
                case "4": LookupVehicle(); break;
                case "5": ShowGateQueue(); break;
                case "6": ShowAvailability(); break;
                case "7": ShowAnalytics(); break;
                case "8": ShowEndOfDayReport(); break;
                case "9": ShowSampleQrTexts(); break;
                case "0": running = false; break;
                default: Console.WriteLine("Please choose a number from the menu."); break;
            }
        }
    }


    /// <summary>
    /// Asks the guard for ONE thing and works out what it is:
    ///   - the path of a QR picture (like C:\\Users\\me\\qr.png)  -> read the picture
    ///   - anything else (scanner output or pasted text)            -> use it as the QR text
    /// So the same prompt works for a USB scanner, copy-paste, AND picture files.
    /// </summary>
    private static IQrReader AskForReader()
    {
        string input = Ask("Scan the QR code, paste its text, or type the path of a QR picture > ");
        string path = input.Trim('"', ' ');

        if (path != "" && File.Exists(path))
            return new ImageQrReader(path);

        // It looks like a file name, but there is no such file: say so clearly.
        string lower = path.ToLowerInvariant();
        bool looksLikePicture = lower.EndsWith(".png") || lower.EndsWith(".jpg") || lower.EndsWith(".jpeg") || lower.EndsWith(".bmp");
        if (looksLikePicture)
            return new ImageQrReader(path);   // it will print "I can't find the picture file"

        return new TextQrReader(input);
    }

    /// <summary>Reads a QR code with ANY reader (IQrReader), then checks the vehicle in or out.</summary>
    private void ScanAndProcess(IQrReader reader)
    {
        Vehicle? scanned = ReadVehicle(reader);
        if (scanned == null) return;

        // Instant check with Binary Search: is this vehicle allowed on campus?
        Vehicle? registered = App.Registry.FindByPlate(scanned.Plate);
        if (registered == null)
        {
            Console.WriteLine($"DENIED: {scanned.Plate} is not in the registry. Use option 3 to register it first.");
            return;
        }
        if (registered.Owner.Id != scanned.Owner.Id)
        {
            Console.WriteLine("DENIED: the ID on the QR code does not match the registered owner of this plate.");
            return;
        }

        Console.WriteLine(App.CheckIn.HandleScan(registered, DateTime.Now));
    }

    private void RegisterFromQr()
    {
        Vehicle? vehicle = ReadVehicle(AskForReader());
        if (vehicle != null) Console.WriteLine(App.RegisterVehicle(vehicle));
    }

    /// <summary>Uses a reader to get the QR text, then turns it into a Vehicle.</summary>
    private static Vehicle? ReadVehicle(IQrReader reader)
    {
        string? text = reader.ReadPayload();
        if (text == null)
        {
            Console.WriteLine("No QR code was read.");
            return null;
        }

        Vehicle? vehicle = QrPayloadParser.TryParse(text, out string error);
        if (vehicle == null) Console.WriteLine($"Bad QR code: {error}");
        return vehicle;
    }

    private void LookupVehicle()
    {
        string text = Ask("Type a plate number or student/employee ID > ");
        Vehicle? found = App.Registry.FindByPlate(text) ?? App.Registry.FindByOwnerId(text);
        Console.WriteLine(found == null ? "No vehicle found." : $"Found: {found}");
    }

    private void ShowGateQueue()
    {
        if (App.CheckIn.GateQueue.IsEmpty)
        {
            Console.WriteLine("Nobody is waiting at the gate.");
            return;
        }
        int place = 1;
        foreach (Vehicle v in App.CheckIn.GateQueue)
            Console.WriteLine($"  {place++}. {v}");
    }

    private void ShowEndOfDayReport()
    {
        if (App.CheckIn.LogCount == 0)
        {
            Console.WriteLine("No vehicles have been logged today.");
            return;
        }

        LogSortKey key = Ask("Sort by:  1 = Arrival time   2 = Course/Department   3 = Plate number > ") switch
        {
            "2" => LogSortKey.Course,
            "3" => LogSortKey.Plate,
            _ => LogSortKey.ArrivalTime
        };

        Console.WriteLine($"\n{"Plate",-9}{"Name",-22}{"Group",-8}{"Slot",-7}{"In",-10}{"Out",-10}");
        foreach (LogRecord r in App.CheckIn.GetSortedLog(key))
        {
            string timeOut = r.TimeOut?.ToString("h:mm tt") ?? "inside";
            Console.WriteLine($"{r.Vehicle.Plate,-9}{r.Vehicle.Owner.Name,-22}{r.Vehicle.Owner.Group,-8}{r.SlotName,-7}{r.TimeIn,-10:h:mm tt}{timeOut,-10}");
        }
    }

    private void ShowSampleQrTexts()
    {
        Console.WriteLine("Paste any of these into option 1 (or turn them into QR pictures with any QR generator):\n");
        foreach (Vehicle v in App.Registry.GetAll())
            Console.WriteLine($"  {QrPayloadParser.ToPayload(v)}");
    }
}
