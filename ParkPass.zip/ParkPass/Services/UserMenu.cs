using ParkPass.Algorithms;
using ParkPass.Models;
using ParkPass.Services.QrCode;

namespace ParkPass.Services;

/// <summary>
/// The menu for a STUDENT or FACULTY driver (the User).
/// A User can only LOOK at their own information. They cannot check anybody in or out.
/// </summary>
public class UserMenu : MenuBase
{
    private readonly Vehicle _myVehicle;

    public UserMenu(ParkPassSystem app, Account me) : base(app, me)
    {
        _myVehicle = me.Vehicle!;   // every User account has a vehicle (the accounts file makes sure of that)
    }

    public override void Run()
    {
        bool running = true;
        while (running)
        {
            Console.WriteLine($"\n===== USER MENU - {Me.Name} =====");
            Console.WriteLine(" 1. My profile and vehicle");
            Console.WriteLine(" 2. Am I parked right now?");
            Console.WriteLine(" 3. Where should I park? (nearest open lot)");
            Console.WriteLine(" 4. Parking availability");
            Console.WriteLine(" 5. Best times to arrive");
            Console.WriteLine(" 6. My QR code text");
            Console.WriteLine(" 0. Log out");

            switch (Ask("Choose > "))
            {
                case "1": Console.WriteLine($"{_myVehicle.Owner.Role}: {_myVehicle}   (ID {_myVehicle.Owner.Id})"); break;
                case "2": ShowMyStatus(); break;
                case "3": ShowMyRoute(); break;
                case "4": ShowAvailability(); break;
                case "5": ShowAnalytics(); break;
                case "6": Console.WriteLine(QrPayloadParser.ToPayload(_myVehicle)); break;
                case "0": running = false; break;
                default: Console.WriteLine("Please choose a number from the menu."); break;
            }
        }
    }

    private void ShowMyStatus()
    {
        LogRecord? record = App.CheckIn.FindActiveRecord(_myVehicle.Plate);
        int queuePlace = App.CheckIn.QueuePosition(_myVehicle.Plate);

        if (record != null)
            Console.WriteLine($"You are parked in {record.LotName}, slot {record.SlotName}, since {record.TimeIn:h:mm tt}.");
        else if (queuePlace > 0)
            Console.WriteLine($"You are waiting at the gate. Your place in line: {queuePlace}.");
        else
            Console.WriteLine("You are not on campus right now.");
    }

    private void ShowMyRoute()
    {
        RouteResult route = App.Routing.FindNearestOpenLot(_myVehicle.Type);
        Console.WriteLine(route.Found
            ? $"Go to {route.Destination}: {string.Join(" -> ", route.Path)} ({route.TotalDistance} m)"
            : $"Sorry, every lot is full for {_myVehicle.Type}s right now. You would join the gate queue.");
    }
}
