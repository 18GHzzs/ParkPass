using System.Text;
using ParkPass.Algorithms;
using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>Ways to sort the end-of-day report.</summary>
public enum LogSortKey
{
    ArrivalTime,
    Course,
    Plate
}

/// <summary>
/// The guard's brain at the gate. It:
///   - checks vehicles IN and OUT,
///   - sends cars to the nearest open lot,
///   - makes vehicles wait in a FIFO line when the campus is full,
///   - lets the waiting vehicles in when someone leaves.
/// </summary>
public class CheckInService
{
    private readonly ParkingZoneService _zones;
    private readonly RoutingService _routing;
    private readonly AnalyticsService _analytics;

    private readonly SimpleList<LogRecord> _dailyLog = new();      // the digital notebook
    private readonly SimpleQueue<Vehicle> _gateQueue = new();      // vehicles waiting outside

    public CheckInService(ParkingZoneService zones, RoutingService routing, AnalyticsService analytics)
    {
        _zones = zones;
        _routing = routing;
        _analytics = analytics;
    }

    public int LogCount => _dailyLog.Count;
    public SimpleQueue<Vehicle> GateQueue => _gateQueue;

    /// <summary>
    /// One scan = one action. If the vehicle is outside, it checks IN.
    /// If it is already inside, it checks OUT. Simple for the guard!
    /// </summary>
    public string HandleScan(Vehicle vehicle, DateTime now)
    {
        LogRecord? inside = FindActiveRecord(vehicle.Plate);
        if (inside != null) return CheckOut(inside, now);

        if (QueuePosition(vehicle.Plate) > 0)
            return $"{vehicle.Plate} is already waiting in the gate queue.";

        return CheckIn(vehicle, now);
    }

    private string CheckIn(Vehicle vehicle, DateTime now)
    {
        // Ask the map: "where is the nearest lot with a free slot for this vehicle?"
        RouteResult route = _routing.FindNearestOpenLot(vehicle.Type);

        if (!route.Found)
        {
            // Everything is full: join the END of the waiting line.
            _gateQueue.Enqueue(vehicle);
            return $"Parking is FULL for {vehicle.Type}s. {vehicle.Plate} joined the gate queue (position {_gateQueue.Count}).";
        }

        ParkingNode slot = _zones.TakeSlot(route.Destination, vehicle.Type, vehicle.Plate)!;
        _dailyLog.Add(new LogRecord(vehicle, route.Destination, slot.Name, now));
        _analytics.RecordArrival(now);

        return $"CHECKED IN  {vehicle.Plate} - {vehicle.Owner.Name} at {now:h:mm tt}\n" +
               $"  Go to: {route.Destination}, slot {slot.Name}\n" +
               $"  Route: {string.Join(" -> ", route.Path)} ({route.TotalDistance} m)";
    }

    private string CheckOut(LogRecord record, DateTime now)
    {
        record.CheckOut(now);
        _zones.ReleaseSlot(record.SlotName);   // the slot is empty again!

        var message = new StringBuilder();
        message.Append($"CHECKED OUT {record.Vehicle.Plate} - {record.Vehicle.Owner.Name} at {now:h:mm tt} " +
                       $"(stayed {(int)record.Duration.TotalHours}h {record.Duration.Minutes}m)");

        // A slot just opened up, so maybe somebody in the line can come in.
        message.Append(AdmitWaitingVehicles(now));
        return message.ToString();
    }

    /// <summary>
    /// Lets vehicles from the FRONT of the line in, one by one, while there is room.
    /// We always look at the front first: first come, first served (FIFO).
    /// </summary>
    private string AdmitWaitingVehicles(DateTime now)
    {
        var message = new StringBuilder();
        while (!_gateQueue.IsEmpty)
        {
            Vehicle next = _gateQueue.Peek();
            if (!_routing.FindNearestOpenLot(next.Type).Found) break;   // still no room for the front vehicle

            _gateQueue.Dequeue();                      // they leave the line...
            message.Append("\n  From the queue -> ").Append(CheckIn(next, now));   // ...and get checked in
        }
        return message.ToString();
    }

    /// <summary>Is this vehicle parked right now? Gives back its log line, or null if not.</summary>
    public LogRecord? FindActiveRecord(string plate)
    {
        foreach (LogRecord record in _dailyLog)
            if (record.IsInside && record.Vehicle.Plate == plate) return record;
        return null;
    }

    /// <summary>Where is this vehicle in the waiting line? 1 = front. Gives 0 if it is not waiting.</summary>
    public int QueuePosition(string plate)
    {
        int position = 1;
        foreach (Vehicle v in _gateQueue)
        {
            if (v.Plate == plate) return position;
            position++;
        }
        return 0;
    }

    /// <summary>Gives back a SORTED COPY of today's log (the original order stays untouched).</summary>
    public SimpleList<LogRecord> GetSortedLog(LogSortKey sortBy)
    {
        SimpleList<LogRecord> copy = _dailyLog.Copy();

        Comparison<LogRecord> rule = sortBy switch
        {
            LogSortKey.Course => (a, b) => string.CompareOrdinal(a.Vehicle.Owner.Group, b.Vehicle.Owner.Group),
            LogSortKey.Plate => (a, b) => string.CompareOrdinal(a.Vehicle.Plate, b.Vehicle.Plate),
            _ => (a, b) => a.TimeIn.CompareTo(b.TimeIn)
        };

        QuickSort.Sort(copy, rule);
        return copy;
    }
}
