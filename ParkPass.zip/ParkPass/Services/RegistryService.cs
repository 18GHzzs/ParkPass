using ParkPass.Algorithms;
using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// The MASTER REGISTRY: the list of all vehicles that are allowed on campus.
/// We keep two sorted lists (one by plate, one by owner ID) so Binary Search can find anyone instantly.
/// </summary>
public class RegistryService
{
    private readonly SimpleList<Vehicle> _byPlate = new();
    private readonly SimpleList<Vehicle> _byOwnerId = new();

    public int Count => _byPlate.Count;

    /// <summary>Adds a vehicle. Returns false if that plate or ID is already registered.</summary>
    public bool Register(Vehicle vehicle)
    {
        if (FindByPlate(vehicle.Plate) != null || FindByOwnerId(vehicle.Owner.Id) != null) return false;

        _byPlate.Add(vehicle);
        _byOwnerId.Add(vehicle);

        // Binary Search only works on sorted lists, so we sort again after adding.
        QuickSort.Sort(_byPlate, (a, b) => string.CompareOrdinal(a.Plate, b.Plate));
        QuickSort.Sort(_byOwnerId, (a, b) => string.CompareOrdinal(a.Owner.Id, b.Owner.Id));
        return true;
    }

    /// <summary>Instant lookup by plate number using Binary Search.</summary>
    public Vehicle? FindByPlate(string plate)
    {
        string clean = Vehicle.NormalizePlate(plate);
        int spot = BinarySearch.Find(_byPlate, clean, v => v.Plate);
        return spot == -1 ? null : _byPlate[spot];
    }

    /// <summary>Instant lookup by student / employee ID using Binary Search.</summary>
    public Vehicle? FindByOwnerId(string ownerId)
    {
        int spot = BinarySearch.Find(_byOwnerId, ownerId.Trim(), v => v.Owner.Id);
        return spot == -1 ? null : _byOwnerId[spot];
    }

    public SimpleList<Vehicle> GetAll() => _byPlate.Copy();
}
