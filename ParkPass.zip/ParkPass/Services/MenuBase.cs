using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// The "parent" of both menus (guard and driver). Things that BOTH can do,
/// like seeing free parking slots, are written once here and inherited by both menus.
/// </summary>
public abstract class MenuBase
{
    protected readonly ParkPassSystem App;
    protected readonly Account Me;   // the person who is logged in

    protected MenuBase(ParkPassSystem app, Account me)
    {
        App = app;
        Me = me;
    }

    /// <summary>Each child menu shows its OWN options. This is POLYMORPHISM.</summary>
    public abstract void Run();

    protected static string Ask(string question)
    {
        Console.Write(question);
        return Console.ReadLine()?.Trim() ?? "";
    }

    protected void ShowAvailability()
    {
        foreach (ParkingNode lot in App.Zones.GetLots())
        {
            Console.WriteLine(lot.Name);
            foreach (VehicleType type in Enum.GetValues<VehicleType>())
                Console.WriteLine($"   {type,-11}: {App.Zones.CountFree(lot.Name, type)} free of {App.Zones.CountTotal(lot.Name, type)}");
        }
    }

    protected void ShowAnalytics()
    {
        string choice = Ask("Which day type?  1 = Regular lecture days   2 = Thursday lab days > ");
        DayProfile profile = choice == "2" ? DayProfile.ThursdayLab : DayProfile.RegularLecture;
        TrafficReport report = App.Analytics.BuildReport(profile);

        Console.WriteLine($"\n--- Traffic profile: {profile} ({report.DaysObserved} day(s) of data) ---");
        if (report.DaysObserved == 0)
        {
            Console.WriteLine("No data yet for this kind of day.");
            return;
        }

        for (int hour = AnalyticsService.FirstHour; hour <= AnalyticsService.LastHour; hour++)
        {
            double avg = report.HourlyAverages[hour];
            Console.WriteLine($"  {HourCount.HourLabel(hour),9} | {new string('#', (int)Math.Round(avg)),-32} {avg:0.0}");
        }

        Console.WriteLine($"\nAverage vehicles per day     : {report.DailyAverage:0.0}");
        Console.WriteLine($"Peak hour                    : {HourCount.HourLabel(report.PeakHour.Hour)} ({report.PeakHour.Average:0.0} vehicles)");
        Console.WriteLine($"Rush-hour stack (top->bottom): {string.Join(", ", report.RushHourStack.Select(h => HourCount.HourLabel(h.Hour)))}");
        Console.WriteLine($"Best times to arrive         : {string.Join(", ", report.BestArrivalHours.Select(h => HourCount.HourLabel(h.Hour)))}");
    }
}
