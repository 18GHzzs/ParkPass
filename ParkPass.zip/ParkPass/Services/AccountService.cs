using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// Reads and writes the ACCOUNTS FILE (accounts.csv).
/// It is a plain text file: one account per line, with the parts split by commas.
/// You can open it with Notepad or Excel and change names, passwords, or add new people.
/// </summary>
public class AccountService
{
    private const int ColumnCount = 9;

    private const string DefaultFile =
@"# ParkPass accounts. You can edit this file with Notepad or Excel, then restart the program.
# One account per line. Lines starting with # are ignored. Do not put commas inside a value.
#
# username,password,role,type,name,idNumber,courseOrDept,plate,vehicleType
#   role        = Operator (security guard)  or  User (student / faculty)
#   type        = Student or Faculty  (leave empty for an Operator)
#   vehicleType = Car or Motorcycle   (leave empty for an Operator)
#
guard1,guard123,Operator,,Guard Rodel,,,,
juan,juan123,User,Student,Juan Dela Cruz,2021100123,BSCS,ABC1234,Car
maria,maria123,User,Student,Maria Santos,2022100456,BSIT,XYZ5678,Car
pedro,pedro123,User,Student,Pedro Reyes,2021100789,BSCE,MNO2468,Motorcycle
carlo,carlo123,User,Student,Carlo Mendoza,2023100321,BSCS,TUV9753,Car
liza,liza123,User,Student,Liza Garcia,2023100654,BSIT,DEF8642,Car
mark,mark123,User,Student,Mark Villanueva,2022100987,BSEE,GHI1122,Motorcycle
ana,ana123,User,Faculty,Prof. Ana Lopez,F-0001,SOIT,QRS1357,Car
";

    private readonly SimpleList<Account> _accounts = new();
    public string FilePath { get; }
    public IEnumerable<Account> Accounts => _accounts;

    public AccountService(string filePath)
    {
        FilePath = Path.GetFullPath(filePath);
        if (!File.Exists(FilePath)) File.WriteAllText(FilePath, DefaultFile);   // first run: make the file
        Load();
    }

    /// <summary>Checks the username and password. Gives back the account, or null if they are wrong.</summary>
    public Account? Login(string username, string password)
    {
        foreach (Account a in _accounts)
        {
            bool sameName = a.Username.Equals(username.Trim(), StringComparison.OrdinalIgnoreCase); // any letter case
            if (sameName && a.Password == password) return a;                                       // password: exact
        }
        return null;
    }

    /// <summary>Adds a new account and saves it at the bottom of the file. False if the username is taken.</summary>
    public bool Add(Account account)
    {
        if (UsernameExists(account.Username)) return false;

        _accounts.Add(account);

        string current = File.ReadAllText(FilePath);
        string newLineIfNeeded = current.EndsWith("\n") || current == "" ? "" : Environment.NewLine;
        File.AppendAllText(FilePath, newLineIfNeeded + ToLine(account) + Environment.NewLine);
        return true;
    }

    private bool UsernameExists(string username)
    {
        foreach (Account a in _accounts)
            if (a.Username.Equals(username, StringComparison.OrdinalIgnoreCase)) return true;
        return false;
    }

    // ----- reading the file -----

    private void Load()
    {
        int lineNumber = 0;
        foreach (string rawLine in File.ReadAllLines(FilePath))
        {
            lineNumber++;
            string line = rawLine.Trim();
            if (line == "" || line.StartsWith("#")) continue;   // skip empty lines and notes

            Account? account = ParseLine(line, out string error);
            if (account == null)
                Console.WriteLine($"[accounts.csv line {lineNumber}] skipped: {error}");
            else if (UsernameExists(account.Username))
                Console.WriteLine($"[accounts.csv line {lineNumber}] skipped: username '{account.Username}' is used twice.");
            else
                _accounts.Add(account);
        }
    }

    private static Account? ParseLine(string line, out string error)
    {
        error = "";
        string[] p = line.Split(',');
        Array.Resize(ref p, Math.Max(p.Length, ColumnCount));   // fill missing columns with nothing
        for (int i = 0; i < p.Length; i++) p[i] = (p[i] ?? "").Trim();

        string username = p[0], password = p[1], role = p[2], type = p[3], name = p[4];
        string id = p[5], group = p[6], plate = p[7], vehicleTypeText = p[8];

        if (username == "" || password == "" || name == "")
        {
            error = "username, password and name cannot be empty.";
            return null;
        }

        // Guard account: no vehicle needed.
        if (role.Equals("Operator", StringComparison.OrdinalIgnoreCase))
            return new Account(username, password, AccountRole.Operator, name, null);

        if (!role.Equals("User", StringComparison.OrdinalIgnoreCase))
        {
            error = "role must be Operator or User.";
            return null;
        }
        if (id == "" || group == "" || plate == "")
        {
            error = "a User needs idNumber, courseOrDept and plate.";
            return null;
        }
        if (!Enum.TryParse(vehicleTypeText, true, out VehicleType vehicleType))
        {
            error = "vehicleType must be Car or Motorcycle.";
            return null;
        }

        User owner;
        if (type.Equals("Student", StringComparison.OrdinalIgnoreCase)) owner = new Student(id, name, group);
        else if (type.Equals("Faculty", StringComparison.OrdinalIgnoreCase)) owner = new Faculty(id, name, group);
        else
        {
            error = "type must be Student or Faculty.";
            return null;
        }

        return new Account(username, password, AccountRole.User, name, new Vehicle(plate, vehicleType, owner));
    }

    // ----- writing one account as a line -----

    private static string ToLine(Account a)
    {
        if (a.Vehicle == null)
            return $"{a.Username},{a.Password},Operator,,{a.Name},,,,";

        Vehicle v = a.Vehicle;
        return $"{a.Username},{a.Password},User,{v.Owner.Role},{v.Owner.Name},{v.Owner.Id},{v.Owner.Group},{v.Plate},{v.Type}";
    }
}
