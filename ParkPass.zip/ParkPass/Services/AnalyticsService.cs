using ParkPass.Algorithms;
using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// Counts how many vehicles arrive each hour, then finds the busiest hours (rush hours)
/// and the quietest hours (best times to arrive).
/// Thursday (lab day) and other days (lecture days) are counted separately.
/// </summary>
public class AnalyticsService
{
    public const int FirstHour = 6;    // campus opens around 6 AM
    public const int LastHour = 21;    // and closes around 9 PM

    // For each kind of day: 24 counters (one for each hour) + the dates we have seen.
    private readonly int[] _lectureCounts = new int[24];
    private readonly int[] _thursdayCounts = new int[24];
    private readonly HashSet<DateTime> _lectureDays = new();
    private readonly HashSet<DateTime> _thursdayDays = new();

    public static DayProfile ProfileOf(DateTime when)
        => when.DayOfWeek == DayOfWeek.Thursday ? DayProfile.ThursdayLab : DayProfile.RegularLecture;

    /// <summary>Call this every time a vehicle arrives. It adds +1 to that hour's counter.</summary>
    public void RecordArrival(DateTime when)
    {
        if (when.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday) return;   // classes are Mon-Fri

        if (ProfileOf(when) == DayProfile.ThursdayLab)
        {
            _thursdayCounts[when.Hour]++;
            _thursdayDays.Add(when.Date);
        }
        else
        {
            _lectureCounts[when.Hour]++;
            _lectureDays.Add(when.Date);
        }
    }

    public TrafficReport BuildReport(DayProfile profile)
    {
        bool isThursday = profile == DayProfile.ThursdayLab;
        int[] counts = isThursday ? _thursdayCounts : _lectureCounts;
        int days = isThursday ? _thursdayDays.Count : _lectureDays.Count;
        int safeDays = Math.Max(1, days);   // never divide by zero

        // Step 1: the AVERAGE number of arrivals for every hour.
        double[] averages = new double[24];
        double dailyTotal = 0;
        for (int hour = 0; hour < 24; hour++)
        {
            averages[hour] = counts[hour] / (double)safeDays;
            dailyTotal += averages[hour];
        }

        // Step 2: the TRAFFIC STACK.
        // We go hour by hour. When a BUSIER hour shows up, we POP (throw away) the quieter
        // hours sitting on top. When we are done, the bottom of the stack is the PEAK hour,
        // and the stack holds the rush-hour "staircase" from busiest (bottom) to quieter (top).
        var rushStack = new SimpleStack<HourCount>();
        for (int hour = FirstHour; hour <= LastHour; hour++)
        {
            var current = new HourCount(hour, averages[hour]);
            while (!rushStack.IsEmpty && rushStack.Peek().Average < current.Average)
                rushStack.Pop();
            rushStack.Push(current);
        }
        HourCount peak = rushStack.PeekBottom();

        // Step 3: the QUIETEST hours = the best times to arrive. We sort all hours (Quick Sort)
        // from least busy to most busy, then take the first three.
        var allHours = new SimpleList<HourCount>();
        for (int hour = FirstHour; hour <= LastHour; hour++)
            allHours.Add(new HourCount(hour, averages[hour]));
        QuickSort.Sort(allHours, (a, b) =>
        {
            int byTraffic = a.Average.CompareTo(b.Average);
            return byTraffic != 0 ? byTraffic : a.Hour.CompareTo(b.Hour);
        });
        var best = new SimpleList<HourCount>();
        for (int i = 0; i < 3 && i < allHours.Count; i++) best.Add(allHours[i]);

        return new TrafficReport
        {
            Profile = profile,
            DaysObserved = days,
            HourlyAverages = averages,
            DailyAverage = dailyTotal,
            PeakHour = peak,
            RushHourStack = rushStack,
            BestArrivalHours = best
        };
    }
}
