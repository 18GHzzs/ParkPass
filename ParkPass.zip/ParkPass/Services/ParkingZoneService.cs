using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// Looks after the parking spaces. It owns the parking TREE and answers
/// questions like "How many car slots are free in the Left Lot?"
/// </summary>
public class ParkingZoneService
{
    private readonly ParkingTree _tree = new();

    public ParkingZoneService()
    {
        // Small numbers on purpose, so the "gate queue" is easy to see when testing.
        _tree.AddLot("Left Lot");
        _tree.AddSection("Left Lot", VehicleType.Car, 3);
        _tree.AddSection("Left Lot", VehicleType.Motorcycle, 2);

        _tree.AddLot("Right Lot");
        _tree.AddSection("Right Lot", VehicleType.Car, 2);
        _tree.AddSection("Right Lot", VehicleType.Motorcycle, 2);
    }

    public int CountFree(string lotName, VehicleType type) => _tree.CountFree(lotName, type);
    public int CountTotal(string lotName, VehicleType type) => _tree.CountTotal(lotName, type);
    public ParkingNode? TakeSlot(string lotName, VehicleType type, string plate) => _tree.TakeFreeSlot(lotName, type, plate);
    public void ReleaseSlot(string slotName) => _tree.ReleaseSlot(slotName);
    public SimpleList<ParkingNode> GetLots() => _tree.GetLots();
}
