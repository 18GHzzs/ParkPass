using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// The "toolbox" of the program. It builds every service once and keeps them together,
/// so the menus only need to ask this one class for what they need.
/// </summary>
public class ParkPassSystem
{
    public AccountService Accounts { get; }
    public RegistryService Registry { get; } = new();
    public ParkingZoneService Zones { get; } = new();
    public AnalyticsService Analytics { get; } = new();
    public RoutingService Routing { get; }
    public CheckInService CheckIn { get; }

    public ParkPassSystem(string accountsFile)
    {
        // Load the accounts file. Every student / faculty account owns a vehicle, so it goes in the registry.
        Accounts = new AccountService(accountsFile);
        foreach (Account account in Accounts.Accounts)
            if (account.Vehicle != null) Registry.Register(account.Vehicle);

        Routing = new RoutingService(Zones);
        CheckIn = new CheckInService(Zones, Routing, Analytics);

        SeedTrafficHistory();
    }

    /// <summary>Registers a new vehicle AND creates its login (username and password = the ID number).</summary>
    public string RegisterVehicle(Vehicle vehicle)
    {
        if (Registry.FindByPlate(vehicle.Plate) != null) return "That plate is already registered.";
        if (Registry.FindByOwnerId(vehicle.Owner.Id) != null) return "That ID number is already registered.";

        var account = new Account(vehicle.Owner.Id, vehicle.Owner.Id, AccountRole.User, vehicle.Owner.Name, vehicle);
        if (!Accounts.Add(account)) return $"The username '{account.Username}' already exists in the accounts file.";

        Registry.Register(vehicle);
        return $"Registered: {vehicle}\nLogin created -> username: {account.Username}, password: {account.Password}";
    }

    // Pretend we already counted traffic for the past two weeks, so the analytics have something to show.
    private void SeedTrafficHistory()
    {
        for (int daysAgo = 1; daysAgo <= 14; daysAgo++)
        {
            DateTime day = DateTime.Today.AddDays(-daysAgo);
            if (day.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday) continue;

            bool labDay = day.DayOfWeek == DayOfWeek.Thursday;
            for (int hour = AnalyticsService.FirstHour; hour <= AnalyticsService.LastHour; hour++)
            {
                int arrivals = labDay
                    ? (hour == 9 ? 28 : hour == 10 ? 26 : hour == 13 ? 22 : hour == 8 ? 18 : 6)
                    : (hour == 7 ? 30 : hour == 8 ? 25 : hour == 13 ? 20 : hour == 12 ? 18 : hour is >= 9 and <= 11 ? 10 : 5);
                arrivals += daysAgo % 3;   // tiny change each day so the numbers look real

                for (int i = 0; i < arrivals; i++)
                    Analytics.RecordArrival(day.AddHours(hour));
            }
        }
    }
}
