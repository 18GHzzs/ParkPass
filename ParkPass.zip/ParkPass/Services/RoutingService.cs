using ParkPass.Algorithms;
using ParkPass.DataStructures;
using ParkPass.Models;

namespace ParkPass.Services;

/// <summary>
/// Finds the nearest parking lot that still has an empty slot, using the road MAP (graph) and DFS.
/// </summary>
public class RoutingService
{
    public const string GateName = "Main Gate";

    private readonly RoadGraph _map = new();
    private readonly ParkingZoneService _zones;

    public RoutingService(ParkingZoneService zones)
    {
        _zones = zones;
        BuildCampusMap();
    }

    /// <summary>Draws the campus map: places first, then the roads (in meters) between them.</summary>
    private void BuildCampusMap()
    {
        _map.AddPlace(GateName);
        _map.AddPlace("Crossing A");
        _map.AddPlace("Crossing B");
        _map.AddPlace("Left Lot", isParkingLot: true);
        _map.AddPlace("Right Lot", isParkingLot: true);

        _map.AddRoad(GateName, "Crossing A", 50);
        _map.AddRoad(GateName, "Crossing B", 80);
        _map.AddRoad("Crossing A", "Crossing B", 40);
        _map.AddRoad("Crossing A", "Left Lot", 120);
        _map.AddRoad("Crossing B", "Right Lot", 60);
        _map.AddRoad("Crossing B", "Left Lot", 200);
    }

    /// <summary>
    /// Finds the closest lot that has a free slot for this type of vehicle.
    /// If every lot is full for that type, the result says "Found = false".
    /// </summary>
    public RouteResult FindNearestOpenLot(VehicleType type)
    {
        // The "goal question": a place is good if it's a parking lot AND still has space.
        return DepthFirstSearch.FindShortestRoute(
            _map, GateName,
            place => place.IsParkingLot && _zones.CountFree(place.Name, type) > 0);
    }
}
