using ParkPass.Models;

namespace ParkPass.Services.QrCode;

/// <summary>
/// Turns the text inside a QR code into a Vehicle object (and back).
///
/// The text has 7 parts separated by "|" and looks like this:
///     PARKPASS|S|2021100123|Juan Dela Cruz|BSCS|ABC1234|Car
///        1     2     3            4          5     6     7
///   1 = secret word so we know it's a ParkPass code
///   2 = S for Student, F for Faculty
///   3 = student / employee ID      4 = name
///   5 = course (or department)     6 = plate number    7 = Car or Motorcycle
/// </summary>
public static class QrPayloadParser
{
    private const string Header = "PARKPASS";

    public static Vehicle? TryParse(string payload, out string error)
    {
        error = "";
        string[] parts = payload.Split('|');

        if (parts.Length != 7 || !parts[0].Trim().Equals(Header, StringComparison.OrdinalIgnoreCase))
        {
            error = "This is not a ParkPass QR code.";
            return null;
        }

        string role = parts[1].Trim().ToUpperInvariant();
        string id = parts[2].Trim();
        string name = parts[3].Trim();
        string group = parts[4].Trim();
        string plate = parts[5].Trim();

        if (id == "" || name == "" || group == "" || plate == "")
        {
            error = "The QR code has empty parts.";
            return null;
        }
        if (!Enum.TryParse(parts[6].Trim(), ignoreCase: true, out VehicleType type))
        {
            error = "Vehicle type must be Car or Motorcycle.";
            return null;
        }

        // Make the right kind of person depending on the role letter.
        User owner;
        if (role == "S") owner = new Student(id, name, group);
        else if (role == "F") owner = new Faculty(id, name, group);
        else
        {
            error = "Role must be S (student) or F (faculty).";
            return null;
        }

        return new Vehicle(plate, type, owner);
    }

    /// <summary>Builds the QR text for a vehicle (you can paste this into any QR generator website).</summary>
    public static string ToPayload(Vehicle v)
        => $"{Header}|{v.Owner.RoleCode}|{v.Owner.Id}|{v.Owner.Name}|{v.Owner.Group}|{v.Plate}|{v.Type}";
}
