namespace ParkPass.Services.QrCode;

/// <summary>
/// The simplest reader: the QR text is already known (the guard typed it, pasted it,
/// or a USB scanner "typed" it for us). It just hands the text back.
/// </summary>
public class TextQrReader : IQrReader
{
    private readonly string _text;

    public TextQrReader(string text)
    {
        _text = text;
    }

    public string Name => "Typed / pasted text";

    public string? ReadPayload() => string.IsNullOrWhiteSpace(_text) ? null : _text.Trim();
}
