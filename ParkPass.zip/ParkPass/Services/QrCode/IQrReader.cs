namespace ParkPass.Services.QrCode;

/// <summary>
/// A "promise" (interface) that every QR reader must keep: it can read a QR code and give back its text.
/// The rest of the program only knows about this promise, so we can swap readers
/// (keyboard scanner, picture file, webcam later...) without changing anything else.
/// This is called POLYMORPHISM + ABSTRACTION.
/// </summary>
public interface IQrReader
{
    /// <summary>A short name shown to the guard, like "USB scanner".</summary>
    string Name { get; }

    /// <summary>Reads one QR code. Returns null when nothing could be read.</summary>
    string? ReadPayload();
}
