using System.Drawing;
using ZXing.Windows.Compatibility;

namespace ParkPass.Services.QrCode;

/// <summary>
/// Reader that opens a PICTURE of a QR code (png, jpg, bmp) and decodes it using the ZXing library.
/// Handy for QR codes saved on a phone screenshot or a printed ID card that was photographed.
/// Note: reading pictures this way works on Windows.
/// </summary>
public class ImageQrReader : IQrReader
{
    private readonly string _filePath;

    public ImageQrReader(string filePath)
    {
        _filePath = filePath.Trim('"', ' ');   // drag-and-drop paths sometimes come with quotes
    }

    public string Name => $"Image file ({Path.GetFileName(_filePath)})";

    public string? ReadPayload()
    {
        if (!File.Exists(_filePath))
        {
            Console.WriteLine($"  I can't find the picture file: {_filePath}");
            return null;
        }

        try
        {
            using var picture = new Bitmap(_filePath);
            var decoder = new BarcodeReader
            {
                AutoRotate = true,   // fix pictures that are turned sideways
                Options =
                {
                    TryHarder = true,       // look more carefully
                    TryInverted = true,     // also try white-on-black codes
                    PossibleFormats = new List<ZXing.BarcodeFormat> { ZXing.BarcodeFormat.QR_CODE }   // we only want QR codes
                }
            };

            ZXing.Result? result = decoder.Decode(picture);   // try to read the QR code
            if (result == null)
                Console.WriteLine("  The picture opened, but I could not find a QR code in it.");
            return result?.Text;
        }
        catch (PlatformNotSupportedException)
        {
            Console.WriteLine("  Reading pictures only works on Windows. Paste the QR text instead (menu option 9 shows samples).");
            return null;
        }
        catch (Exception ex) when (ex is ArgumentException or OutOfMemoryException)
        {
            Console.WriteLine($"  That file is not a picture I can open: {ex.Message}");
            return null;
        }
    }
}
