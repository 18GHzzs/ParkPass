namespace ParkPass.Services.QrCode;

/// <summary>
/// Reader for normal USB / handheld QR scanners.
/// These scanners pretend to be a keyboard: when you scan, they "type" the QR text and press Enter.
/// So we just wait for a line of text. (You can also type or paste the text by hand to test.)
/// </summary>
public class KeyboardQrReader : IQrReader
{
    public string Name => "USB / keyboard-style scanner";

    public string? ReadPayload()
    {
        Console.Write("Scan the QR code now (or paste its text) > ");
        string? line = Console.ReadLine();
        return string.IsNullOrWhiteSpace(line) ? null : line.Trim();
    }
}
